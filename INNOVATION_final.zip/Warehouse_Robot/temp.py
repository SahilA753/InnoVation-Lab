
import pygame
import sys
from queue import Queue
import copy


WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
CYAN = (0, 255, 255)
MAGENTA = (255, 0, 255)
ORANGE = (255, 165, 0)
GRAY = (128, 128, 128)
BROWN = (165, 42, 42)
PURPLE = (128, 0, 128)
PINK = (255, 192, 203)


# Initialize Pygame
pygame.init()

no_of_frames_used =0
# Function Definitions

def func(v, i1, j1, i2, j2, charac, visited,):

    n = len(matrix)
    m= len(matrix[0])
    q = Queue()
    q.put(((0, 'X'), (i1, j1)))

    while not q.empty():
        alpha, beta = q.queue[0][1]
        visited[alpha][beta] = 1
        charac[alpha][beta] = q.queue[0][0][1]
        dist = q.queue[0][0][0]
        q.get()

        if alpha == i2 and beta == j2:
            main_dist = dist
            break

        if alpha - 1 >= 0 and visited[alpha - 1][beta] == 0:
            if alpha - 1 == i2 and beta == j2:
                if dist != 0:
                    q.put(((dist + 1, 'U'), (alpha - 1, beta)))
            elif v[alpha - 1][beta] == 0:
                q.put(((dist + 1, 'U'), (alpha - 1, beta)))

        if alpha + 1 < n and visited[alpha + 1][beta] == 0:
            if alpha + 1 == i2 and beta == j2:
                if dist != 0:
                    q.put(((dist + 1, 'D'), (alpha + 1, beta)))
            elif v[alpha + 1][beta] == 0:
                q.put(((dist + 1, 'D'), (alpha + 1, beta)))

        if beta - 1 >= 0 and visited[alpha][beta - 1] == 0:
            if alpha == i2 and beta - 1 == j2:
                if dist != 0:
                    q.put(((dist + 1, 'L'), (alpha, beta - 1)))
            elif v[alpha][beta - 1] == 0:
                q.put(((dist + 1, 'L'), (alpha, beta - 1)))

        if beta + 1 < m and visited[alpha][beta + 1] == 0:
            if alpha == i2 and beta + 1 == j2:
                if dist != 0:
                    q.put(((dist + 1, 'R'), (alpha, beta + 1)))
            elif v[alpha][beta + 1] == 0:
                q.put(((dist + 1, 'R'), (alpha, beta + 1)))

    ans = ""
    q2 = Queue()
    q2.put((i2, j2))

    while not q2.empty():
        alpha, beta = q2.queue[0]
        q2.get()
        ans += charac[alpha][beta]

        if charac[alpha][beta] == 'L':
            q2.put((alpha, beta + 1))
        elif charac[alpha][beta] == 'R':
            q2.put((alpha, beta - 1))
        elif charac[alpha][beta] == 'D':
            q2.put((alpha - 1, beta))
        elif charac[alpha][beta] == 'U':
            q2.put((alpha + 1, beta))
        elif charac[alpha][beta] == 'X':
            break

    ans = ans[:-1][::-1]
    return ans


def matrix_maker(alpha, beta, NUM_SQUARE_A, NUM_SQUARE_B):
    matrix = [[0 for _ in range(beta)] for _ in range(alpha)]
    
    for i in range(alpha):
        for j in range(beta):
            if j % 4 not in [0, 1] and i not in [0, alpha - 1, 1, alpha-2,NUM_SQUARE_A+2 , NUM_SQUARE_A + NUM_SQUARE_B + 3]:
                matrix[i][j] = 1
    matrix[0][beta//2-2]=2
    matrix[0][beta//2-3]=2
    matrix[0][beta//2+1]=2
    matrix[0][beta//2+2]=2
    matrix[alpha-1][beta//2-2]=2
    matrix[alpha-1][beta//2-3]=2
    matrix[alpha-1][beta//2+1]=2
    matrix[alpha-1][beta//2+2]=2
    return matrix

def draw_lines_of_squares(screen, width, height, square_size, num_squares, num_lines, x_pos, y_pos):
    squares = []

    for line in range(num_lines):
        alpha = y_pos

        for i in range(num_squares):
            square1 = pygame.Rect((x_pos, alpha, square_size / 2, square_size))
            square2 = pygame.Rect((x_pos + square_size / 2, alpha, square_size / 2, square_size))
            squares.extend([square1, square2])
            alpha += square_size

        x_pos += 2 * square_size

    for square in squares:
        pygame.draw.rect(screen, RED, square)
        pygame.draw.rect(screen, BLACK, square, 1)



def update_matrix(no_of_robot, Robotic_String,matrix,robot_locations, base_matrix, storage_locations, parsed_requests):

    for i in range(no_of_robot):
        robot_x = robot_locations[i][0]
        robot_y = robot_locations[i][1]
        if(len(Robotic_String[i])==0 and parsed_requests[0]<len(storage_locations)):
            visited = [[0] * beta for _ in range(alpha)]
            charac = [['0'] * beta for _ in range(alpha)]
            # print(parsed_requests[0])
            storage_x = storage_locations[parsed_requests[0]][0]
            storage_y = storage_locations[parsed_requests[0]][1]
            if parsed_requests[0]-no_of_robot>=0:
                prev_storex = storage_locations[parsed_requests[0]-no_of_robot][0]
                prev_storey = storage_locations[parsed_requests[0]-no_of_robot][1]
                matrix[storage_x][storage_y]=base_matrix[storage_x][storage_y]
            matrix[storage_x][storage_y]=4

            Robotic_String[i] = func(matrix,robot_x,robot_y,storage_x,storage_y,charac, visited)
            B = ""
            for char in Robotic_String[i]:
                if char == 'L':
                    B += 'R'
                elif char == 'R':
                    B += 'L'
                elif char == 'U':
                    B += 'D'
                elif char == 'D':
                    B += 'U'
            reversed_string = "".join(reversed(B))

            Robotic_String[i] += 'X'*5
            Robotic_String[i] += reversed_string

            # print(Robotic_String)
            parsed_requests[0]+=1
        elif len(Robotic_String[i])>0:
            if Robotic_String[i][0]=='L':
                matrix[robot_x][robot_y-1] = 3
                robot_list = list(robot_locations[i])
                robot_list[0] = robot_x
                robot_list[1] = robot_y-1
                robot_locations[i] = tuple(robot_list)
            elif Robotic_String[i][0]=='R':
                matrix[robot_x][robot_y+1] =3
                robot_list = list(robot_locations[i])
                robot_list[0] = robot_x
                robot_list[1] = robot_y+1
                robot_locations[i] = tuple(robot_list)
            elif Robotic_String[i][0]=='U':
                matrix[robot_x-1][robot_y] =3
                robot_list = list(robot_locations[i])
                robot_list[0] = robot_x-1
                robot_list[1] = robot_y
                robot_locations[i] = tuple(robot_list)
            elif Robotic_String[i][0]=='D':
                matrix[robot_x+1][robot_y] =3
                robot_list = list(robot_locations[i])
                robot_list[0] = robot_x+1
                robot_list[1] = robot_y
                robot_locations[i] = tuple(robot_list)
            Robotic_String[i]= Robotic_String[i][1:]
            matrix[robot_x][robot_y] = base_matrix[robot_x][robot_y]
    
    return matrix


def Graphics(matrix, no_of_robot, Robotic_String, robot_locations, base_matrix, storage_locations, parsed_requests):
    global no_of_frames_used
    screen = pygame.display.set_mode((width, height))
    pygame.display.set_caption("Pygame Template")

    # Game loop
    clock = pygame.time.Clock()
    while True:
        no_of_frames_used+=1
        if parsed_requests[0] >= len(storage_locations):
            parsed_requests[0]+=1
        
        if parsed_requests[0] >= len(storage_locations)+25:
            return
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        # Update the game state
        # Draw to the screen
        screen.fill(WHITE)
        
        # if parsed_requests[0]<len(storage_locations):
        matrix = update_matrix(no_of_robot, Robotic_String, matrix, robot_locations, base_matrix, storage_locations,parsed_requests)
        print(Robotic_String)
        # if parsed_requests==len(storage_locations):
        #     break
        for rows in matrix:
            print(rows)

        print("matrix")

        for rows in base_matrix:
            print(rows)
        print("base_matrix")
        
        for i in range(len(matrix)):
            for j in range(len(matrix[0])):
                rect = pygame.Rect(j * SQUARE_SIZE / 2, i * SQUARE_SIZE, SQUARE_SIZE / 2, SQUARE_SIZE)

                if matrix[i][j] == 1:
                    pygame.draw.rect(screen, RED, rect)
                    pygame.draw.rect(screen, BLACK, rect, 1)
                elif matrix[i][j] == 2:
                    pygame.draw.rect(screen, GREEN, rect)
                elif matrix[i][j] == 3:
                    pygame.draw.rect(screen, BLUE, rect)
                elif matrix[i][j] == 4:
                    pygame.draw.rect(screen, YELLOW, rect)
                elif matrix[i][j] == 0:
                    pygame.draw.rect(screen, WHITE, rect)
                    # pygame.draw.rect(screen, BLACK, rect, 1)

        # Additional drawing and gameplay logic can go here

        pygame.display.flip()

        # Control the frame rate
        clock.tick(10)





#MAIN DRIVER
# Get user input for screen dimensions and square size
width = int(input("Enter the width of the screen: "))
height = int(input("Enter the height of the screen: "))
SQUARE_SIZE = int(input("Enter the Block Size: "))

# Ensure even width and height for symmetry
width = SQUARE_SIZE * (width // SQUARE_SIZE + 1) if width // SQUARE_SIZE % 2 == 0 else SQUARE_SIZE * (width // SQUARE_SIZE)
height = SQUARE_SIZE*(height//SQUARE_SIZE)

# Set initial x_pos based on width and calculate number of lines
x_pos = (width % SQUARE_SIZE + SQUARE_SIZE) // 2 if width // SQUARE_SIZE % 2 == 0 else SQUARE_SIZE
NUM_LINES = int((width // SQUARE_SIZE) / 2) if width // SQUARE_SIZE % 2 == 0 else int((width // SQUARE_SIZE) / 2)

# Calculate section and square dimensions
depot_section = 2*SQUARE_SIZE
aisle_height = height - 2 * depot_section - 2*SQUARE_SIZE
total_number_square = aisle_height // SQUARE_SIZE
NUM_SQUARE_A = int(total_number_square * 0.6)
NUM_SQUARE_B = int(total_number_square * 0.3)
NUM_SQUARE_C = int(total_number_square * 0.1)
NUM_SQUARE_A+= total_number_square - NUM_SQUARE_A - NUM_SQUARE_B - NUM_SQUARE_C

# Calculate matrix dimensions and create the matrix
alpha = NUM_SQUARE_A + NUM_SQUARE_B + NUM_SQUARE_C + 6
beta = width // SQUARE_SIZE + width // SQUARE_SIZE

matrix = matrix_maker(alpha, beta, NUM_SQUARE_A, NUM_SQUARE_B)

base_matrix = copy.deepcopy(matrix)

# Initialize variables for path finding
# vis = [[0] * beta for _ in range(alpha)]
# charac = [['0'] * beta for _ in range(alpha)]

# Robot movement and matrix updates

no_of_robot = int(input("Input the number of Robots!"))

robot_locations = []
parsed_requests = [0]

# Use a for loop to append pairs to the array
for i in range(no_of_robot):
    if i%4==0:
        x = alpha-1
        y = beta//2-3
    if i%4==1:
        x = alpha-1
        y = beta//2-2
    if i%4==2:
        x = alpha-1
        y = beta//2+1
    if i%4==3:
        x = alpha-1
        y = beta//2+2
    robot_locations.append((x, y))

# Number of storage locations
# no_of_storage = 10
# storage_locations = []

# for i in range(no_of_storage):
#     x = int(input(f"Enter the X position for Storage Location {i + 1}: "))
#     y = int(input(f"Enter the Y position for Storage Location {i + 1}: "))
#     storage_locations.append((x, y))


import random

no_of_storage = 10
storage_locations = []

for i in range(no_of_storage):
    x = random.randint(0, 25)
    y = random.randint(0, 25)
    storage_locations.append((x, y))

print("Randomly generated storage locations:")
print(storage_locations)


Robotic_String = [""] * no_of_robot


for i in range(no_of_robot):
    visited = [[0] * beta for _ in range(alpha)]
    charac = [['0'] * beta for _ in range(alpha)]
    Robotic_String[i] = func(matrix, robot_locations[i][0],robot_locations[i][0], storage_locations[i][i], storage_locations[0])
for rows in matrix:
    print(rows)
#print(len(Robotic_String))
#print(storage_locations[0][1])

Graphics(matrix,no_of_robot, Robotic_String, robot_locations,base_matrix,storage_locations,parsed_requests)
print("Number of Frames Used is : ", no_of_frames_used-30)

