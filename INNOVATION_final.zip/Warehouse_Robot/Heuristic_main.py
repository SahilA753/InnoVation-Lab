
import pygame
import sys
from queue import Queue
import copy
import time

WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
CYAN = (0, 255, 255)
MAGENTA = (255, 0, 255)
ORANGE = (255, 165, 0)
GRAY = (128, 128, 128)
BROWN = (165, 42, 42)
PURPLE = (128, 0, 128)
PINK = (255, 192, 203)


# Initialize Pygame
pygame.init()

no_of_frames_used =0
ratio = 0.65
ratio_for_dist_per_time=4
# Function Definitions

def func(v, i1, j1, i2, j2, charac, visited,):

    n = len(matrix)
    m= len(matrix[0])
    q = Queue()
    q.put(((0, 'X'), (i1, j1)))

    while not q.empty():
        alpha, beta = q.queue[0][1]
        visited[alpha][beta] = 1
        charac[alpha][beta] = q.queue[0][0][1]
        dist = q.queue[0][0][0]
        q.get()

        if alpha == i2 and beta == j2:
            main_dist = dist
            break

        if alpha - 1 >= 0 and visited[alpha - 1][beta] == 0:
            if alpha - 1 == i2 and beta == j2:
                if dist != 0:
                    q.put(((dist + 1, 'U'), (alpha - 1, beta)))
            elif v[alpha - 1][beta] == 0:
                q.put(((dist + 1, 'U'), (alpha - 1, beta)))

        if alpha + 1 < n and visited[alpha + 1][beta] == 0:
            if alpha + 1 == i2 and beta == j2:
                if dist != 0:
                    q.put(((dist + 1, 'D'), (alpha + 1, beta)))
            elif v[alpha + 1][beta] == 0:
                q.put(((dist + 1, 'D'), (alpha + 1, beta)))

        if beta - 1 >= 0 and visited[alpha][beta - 1] == 0:
            if alpha == i2 and beta - 1 == j2:
                if dist != 0:
                    q.put(((dist + 1, 'L'), (alpha, beta - 1)))
            elif v[alpha][beta - 1] == 0:
                q.put(((dist + 1, 'L'), (alpha, beta - 1)))

        if beta + 1 < m and visited[alpha][beta + 1] == 0:
            if alpha == i2 and beta + 1 == j2:
                if dist != 0:
                    q.put(((dist + 1, 'R'), (alpha, beta + 1)))
            elif v[alpha][beta + 1] == 0:
                q.put(((dist + 1, 'R'), (alpha, beta + 1)))

    ans = ""
    q2 = Queue()
    q2.put((i2, j2))

    while not q2.empty():
        alpha, beta = q2.queue[0]
        q2.get()
        ans += charac[alpha][beta]

        if charac[alpha][beta] == 'L':
            q2.put((alpha, beta + 1))
        elif charac[alpha][beta] == 'R':
            q2.put((alpha, beta - 1))
        elif charac[alpha][beta] == 'D':
            q2.put((alpha - 1, beta))
        elif charac[alpha][beta] == 'U':
            q2.put((alpha + 1, beta))
        elif charac[alpha][beta] == 'X':
            break

    ans = ans[:-1][::-1]
    return ans


def matrix_maker(alpha, beta, NUM_SQUARE_A, NUM_SQUARE_B):
    matrix = [[0 for _ in range(beta)] for _ in range(alpha)]
    
    for i in range(alpha):
        for j in range(beta):
            if j % 4 not in [0, 1] and i not in [0, alpha - 1, 1, alpha-2,NUM_SQUARE_A+2 , NUM_SQUARE_A + NUM_SQUARE_B + 3]:
                matrix[i][j] = 1
    matrix[0][beta//2-2]=2
    matrix[0][beta//2-3]=2
    matrix[0][beta//2+1]=2
    matrix[0][beta//2+2]=2
    matrix[alpha-1][beta//2-2]=2
    matrix[alpha-1][beta//2-3]=2
    matrix[alpha-1][beta//2+1]=2
    matrix[alpha-1][beta//2+2]=2
    return matrix

def draw_lines_of_squares(screen, width, height, square_size, num_squares, num_lines, x_pos, y_pos):
    squares = []

    for line in range(num_lines):
        alpha = y_pos

        for i in range(num_squares):
            square1 = pygame.Rect((x_pos, alpha, square_size / 2, square_size))
            square2 = pygame.Rect((x_pos + square_size / 2, alpha, square_size / 2, square_size))
            squares.extend([square1, square2])
            alpha += square_size

        x_pos += 2 * square_size

    for square in squares:
        pygame.draw.rect(screen, RED, square)
        pygame.draw.rect(screen, BLACK, square, 1)






#MAIN DRIVER
# Get user input for screen dimensions and square size
width = int(input("Enter the width of the screen: "))
height = int(input("Enter the height of the screen: "))
SQUARE_SIZE = int(input("Enter the Block Size: "))

# Ensure even width and height for symmetry
width = SQUARE_SIZE * (width // SQUARE_SIZE + 1) if width // SQUARE_SIZE % 2 == 0 else SQUARE_SIZE * (width // SQUARE_SIZE)
height = SQUARE_SIZE*(height//SQUARE_SIZE)

# Set initial x_pos based on width and calculate number of lines
x_pos = (width % SQUARE_SIZE + SQUARE_SIZE) // 2 if width // SQUARE_SIZE % 2 == 0 else SQUARE_SIZE
NUM_LINES = int((width // SQUARE_SIZE) / 2) if width // SQUARE_SIZE % 2 == 0 else int((width // SQUARE_SIZE) / 2)

# Calculate section and square dimensions
depot_section = 2*SQUARE_SIZE
aisle_height = height - 2 * depot_section - 2*SQUARE_SIZE
total_number_square = aisle_height // SQUARE_SIZE
NUM_SQUARE_A = int(total_number_square * 0.6)
NUM_SQUARE_B = int(total_number_square * 0.3)
NUM_SQUARE_C = int(total_number_square * 0.1)
NUM_SQUARE_A+= total_number_square - NUM_SQUARE_A - NUM_SQUARE_B - NUM_SQUARE_C

# Calculate matrix dimensions and create the matrix
alpha = NUM_SQUARE_A + NUM_SQUARE_B + NUM_SQUARE_C + 6
beta = width // SQUARE_SIZE + width // SQUARE_SIZE

matrix = matrix_maker(alpha, beta, NUM_SQUARE_A, NUM_SQUARE_B)

base_matrix = copy.deepcopy(matrix)

# Initialize variables for path finding
# vis = [[0] * beta for _ in range(alpha)]
# charac = [['0'] * beta for _ in range(alpha)]

# Robot movement and matrix updates

no_of_robot = int(input("Input the number of Robots!"))

robot_locations = [[] for _ in range(no_of_robot)]

parsed_requests = [0]

# Use a for loop to append pairs to the array
for i in range(no_of_robot):
    if i%4==0:
        x = alpha-1
        y = beta//2-3
    if i%4==1:
        x = alpha-1
        y = beta//2-2
    if i%4==2:
        x = alpha-1
        y = beta//2+1
    if i%4==3:
        x = alpha-1
        y = beta//2+2
    robot_locations[i].append(x)
    robot_locations[i].append(y)

# Number of storage locations
# no_of_storage = 10
# storage_locations = []

# for i in range(no_of_storage):
#     x = int(input(f"Enter the X position for Storage Location {i + 1}: "))
#     y = int(input(f"Enter the Y position for Storage Location {i + 1}: "))
#     storage_locations.append((x, y))


import random

no_of_storage = 10
no_of_storage = 10
storage_locations = [
    (3, 7),
    (12, 9),
    (5, 2),
    (8, 14),
    (10, 6),
    (2, 11),
    (14, 4),
    (1, 13),
    (6, 0),
    (9, 8),
    (4, 10),
    (13, 1),
    (7, 5),
    (11, 3),
    (0, 12),
    (15, 9),
    (8, 2),
    (2, 14),
    (6, 11),
    (12, 3),
    (1, 8),
    (10, 0),
    (5, 13),
    (3, 6),
    (14, 12),
    (9, 4),
    (4, 7),
    (7, 1),
    (13, 10),
    (11, 15),
]

# storage_locations = []

# for i in range(no_of_storage):
#     x = random.randint(0, 15)
#     y = random.randint(0, 15)
#     storage_locations.append((x, y))

print("Randomly generated storage locations:")
print(storage_locations)


Robotic_String = [""] * no_of_robot


Robotic_String = [""] * no_of_robot

robot_time = []
robot_total_load = []
robot_extra_load = []

for i in range(no_of_robot):
    # robot_time.append(0)
    robot_extra_load.append(0)
    robot_total_load.append(0)

Robot_item = [[] for _ in range(no_of_robot)]


total_extra_workload =0

for i in range(no_of_robot):
    visited = [[0] * beta for _ in range(alpha)]
    charac = [['0'] * beta for _ in range(alpha)]
    z1 = func(matrix,robot_locations[i][0],robot_locations[i][0],storage_locations[parsed_requests[0]][0], storage_locations[parsed_requests[0]][1],charac,visited)
    robot_time.append(3*len(z1))
    robot_total_load[i]+=2*4*len(z1)+ 1*5*len(z1)
    robot_extra_load[i]+=len(z1)
    robot_locations[i][0] = storage_locations[parsed_requests[0]][0]
    robot_locations[i][1] = storage_locations[parsed_requests[0]][1]
    Robot_item[i].append(parsed_requests[0])
    parsed_requests[0]+=1


while(parsed_requests[0]<len(storage_locations)):
                alpha = 100000
                ind = 0
                for j in range(len(robot_locations)):
                    visited = [[0] * len(matrix[0]) for _ in range(len(matrix))]
                    charac = [['0'] * len(matrix[0]) for _ in range(len(matrix))]
                    str1 = (func(base_matrix,robot_locations[j][0],robot_locations[j][1],storage_locations[parsed_requests[0]][0],storage_locations[parsed_requests[0]][1],charac, visited))
                    x1= len(str1)
                    if j%4==0:
                        x = len(matrix)-1
                        y = len(matrix[0])//2-3
                    if j%4==1:
                        x = len(matrix)-1
                        y = len(matrix[0])//2-2
                    if j%4==2:
                        x = len(matrix)-1
                        y = len(matrix[0])//2+1
                    if j%4==3:
                        x = len(matrix)-1
                        y = len(matrix[0])//2+2
                    visited = [[0] * len(matrix[0]) for _ in range(len(matrix))]
                    charac = [['0'] * len(matrix[0]) for _ in range(len(matrix))]
                    str2 = func(base_matrix,storage_locations[parsed_requests[0]][0],storage_locations[parsed_requests[0]][1],x,y,charac, visited)
                    x2 = len(str2)
                    if(alpha>(1-ratio)*robot_time[j]+ ratio*(x1+2*x2)):
                        alpha = (1-ratio)*robot_time[j]+ ratio*(x1+2*x2)
                        ind = j
                
                # print(robot_time[0])
                # print(robot_time[1])
                # print(ind)
                # print("hi")
                # print(" ")
                
                
                visited = [[0] * len(matrix[0]) for _ in range(len(matrix))]
                charac = [['0'] * len(matrix[0]) for _ in range(len(matrix))]
                str3 = func(base_matrix,robot_locations[ind][0],robot_locations[ind][1],storage_locations[parsed_requests[0]][0],storage_locations[parsed_requests[0]][1],charac, visited)
                robot_time[ind]+= len(str3)
                robot_extra_load[ind]+= len(str3)
                robot_total_load[ind]+=4*len(str3)
                if ind%4==0:
                    x = len(matrix)-1
                    y = len(matrix[0])//2-3
                if ind%4==1:
                    x = len(matrix)-1
                    y = len(matrix[0])//2-2
                if ind%4==2:
                    x = len(matrix)-1
                    y = len(matrix[0])//2+1
                if ind%4==3:
                    x = len(matrix)-1
                    y = len(matrix[0])//2+2
                visited = [[0] * len(matrix[0]) for _ in range(len(matrix))]
                charac = [['0'] * len(matrix[0]) for _ in range(len(matrix))]
                str3 = func(base_matrix,storage_locations[parsed_requests[0]][0],storage_locations[parsed_requests[0]][1],x,y,charac, visited)   
                robot_time[ind]+= 2*len(str3)  
                robot_total_load[ind]+=5*len(str3)+ 4*len(str3) 
                robot_locations[ind][0] = storage_locations[parsed_requests[0]][0]
                robot_locations[ind][1] = storage_locations[parsed_requests[0]][1]
                # print(ind)
                # print(Robot_item[0])
                # print(Robot_item[1])
                Robot_item[ind].append(parsed_requests[0])
                # print(Robot_item[0])
                # print(Robot_item[1])   
                parsed_requests[0]+=1


total_time =0
total_workload = 0
for i in range(no_of_robot):
    print("All the info for robot",i)
    print("All items in robot",i)
    print(Robot_item[i])
    print("Total time and cost for robot",i)
    print(robot_time[i], robot_time[i]*ratio_for_dist_per_time)
    print(robot_total_load[i])
    print("Extra Load for robot",i)
    print(robot_extra_load[i]*ratio_for_dist_per_time)
    total_extra_workload+=robot_extra_load[i]
    total_workload+= robot_time[i]*ratio_for_dist_per_time
    total_time = max(total_time,robot_time[i])

print("Total time", total_time)
print("Total cost", total_workload)
print("Total Extra Cost (Empty robots just to reach objects)",total_extra_workload)




